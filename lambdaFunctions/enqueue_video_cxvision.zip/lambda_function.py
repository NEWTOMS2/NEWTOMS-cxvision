import json
import urllib.parse
import boto3
import uuid
import os
import urllib3
from botocore.exceptions import ClientError

print('Loading function')

s3_client = boto3.client('s3')
sage_client = boto3.client('runtime.sagemaker')
lambda_client = boto3.client('lambda')
sqs = boto3.client('sqs')
sns = boto3.client('sns')

queue_url = os.environ['QUEUE_URL']
sns_topic_arn = os.environ['SNS_TOPIC_ARN']
endpoint_name = os.environ['ENDPOINT_NAME']
postprocess_output_lambda = os.environ['POSTPROCESS_OUTPUT_LAMBDA']

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    video_s3_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    video_name = video_s3_key.split('/')[-1].rsplit('.',1)[0]
    video_file = video_s3_key.split('/')[-1]
    
    if (video_name == ''):
        return
    
    try:
        print('New video detected at ', 's3://' + bucket + '/' + video_s3_key)
        
        
        # DOWNLOAD VIDEO (FROM S3) TO PROCESS
        
        video_download_path = f'/tmp/{video_file}'
        s3_client.download_file(bucket, video_s3_key, video_download_path)
        
        # BUILD REQUEST TO SEND TO SQS QUEUE
        
        data = {
            "detection_threshold": int(os.environ.get('DETECTION_THRESHOLD', "50")),
            "process_video_quantity": "1",
            "blurring": (os.environ.get('BLURRING', "False")).capitalize(),
            "timezone": os.environ.get('TIMEZONE', "America/Caracas"),
            "refresh_threshold": int(os.environ.get('REFRESH_THRESHOLD', "1")),
            "dwell_zone": os.environ.get('DWELL_ZONE', "[]"),
            "service_zone": os.environ.get('SERVICE_ZONE', "[]"),
            "video_name": video_file,
            "video": f"{bucket}/{video_s3_key}"
        }
        
        sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(data),
            MessageGroupId=bucket
        )
        
        # GET SQS QUEUE NUMBER OF MESSAGES
        
        queue_messages_quantity = sqs.get_queue_attributes(
            QueueUrl=queue_url,
            AttributeNames=['ApproximateNumberOfMessages']
        )
        queue_messages_quantity = queue_messages_quantity["Attributes"]["ApproximateNumberOfMessages"]
        
        print("Messages in queue: ", queue_messages_quantity)   
        
        # IF THERE IS ONLY ONE MESSAGE IN QUEUE, THEN THE ENDPOINT WILL BE INVOKED
        
        if int(queue_messages_quantity) <= 1:
            
             # BUILD PAYLOAD AND INVOKE SAGEMAKER ENDPOINT
            
            data['video'] = ("video.mp4", open(video_download_path, "rb").read(), "video/mp4")
            payload, content_type = urllib3.encode_multipart_formdata(data)
            response = sage_client.invoke_endpoint(
                EndpointName=endpoint_name,
                ContentType=content_type,
                Body=payload
            )
            
            print("Endpoint invoked")
        
            # Read success/failure response
            response_code = response['ResponseMetadata']['HTTPStatusCode']
            response_body = response['Body'].read().decode('utf-8')
            response = {'StatusCode': response_code, 'Body':response_body }
            
            if response_code == 200:
                
                # UPLOAD ENDPOINT RESULT TO S3 (METRICS AND DETECTIONS)
                tracking_resume = "".join(json.loads(response_body)['resume']) 
                
                s3_upload_path = f'{video_name}_output'
                s3_metrics_file_path = f'{s3_upload_path}/{video_name}_output.json'
                s3_tracking_resume_file_path = f'{s3_upload_path}/{video_name}_metrics.txt'
                
                s3_client.put_object(
                    Bucket = bucket,
                    Key = s3_metrics_file_path,
                    Body = response_body,
                    ContentType = 'application/json'
                )
                
                print('{} uploaded successfully to S3 bucket {}'.format(s3_metrics_file_path, bucket))
                s3_client.put_object(
                    Bucket = bucket,
                    Key = s3_tracking_resume_file_path,
                    Body = tracking_resume,
                    ContentType = 'text/plain'
                )
                print('{} uploaded successfully to S3 bucket {}'.format(s3_tracking_resume_file_path, bucket))
                
                # INVOKE LAMBDA FUNCTION TO POSTPROCESS RESULT (ASYNC)
                
                lambda_payload = {
                  "bucket": bucket,
                  "s3_upload_path": s3_upload_path,
                  "s3_video_path": video_s3_key,
                  "s3_metrics_path": s3_metrics_file_path
                }
                
                lambda_client.invoke(
                    FunctionName=postprocess_output_lambda, 
                    InvocationType='Event',
                    Payload=json.dumps(lambda_payload)
                )
                     
                # NOTIFY SUCCESSFUL REQUEST PROCESSING

                sns.publish(
                    TopicArn=sns_topic_arn,
                    Message=f'{video_file} processed successfully',
                )
                print('Sns notification sent')
            
            
            return response_body
            
        response = {'StatusCode': 200, 'Body': "New request queued. It will be processed when the previous request has been successfully processed"} 
        print(response)
        return response
        
    except ClientError as e:
        print(e)
        # Return failure code
        if e.response['Error']['Code'] == 'ModelError':
            response = json.loads(e.response['OriginalMessage'])
            return {'StatusCode': response["code"], 'Body': response["type"]}
            
    except Exception as e:
        print(e)
        raise e



    
