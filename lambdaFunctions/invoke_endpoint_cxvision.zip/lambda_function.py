import json
import urllib.parse
import boto3
import os
import urllib3

print('Loading function')

s3_client = boto3.client('s3')
sage_client = boto3.client('runtime.sagemaker')
lambda_client = boto3.client('lambda')
sqs = boto3.client('sqs')
sns = boto3.client('sns')

queue_url = os.environ['QUEUE_URL']
sns_topic_arn = os.environ['SNS_TOPIC_ARN']
endpoint_name = os.environ['ENDPOINT_NAME']
postprocess_output_lambda = os.environ['POSTPROCESS_OUTPUT_LAMBDA']

def lambda_handler(event, context):

    try:
        print("New message: ", event)
        sqs_messages = sqs.receive_message(
            QueueUrl=queue_url,
            AttributeNames=['ReceiptHandle','Body'],
            MaxNumberOfMessages=2
        )
        print("SQS messages retrived: ", sqs_messages)

        sqs_messages = sqs_messages["Messages"]
        
        message_to_delete = sqs_messages[0]
        
        print('Message to delete: ',message_to_delete)
        sqs.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=message_to_delete["ReceiptHandle"]
        )
        if len(sqs_messages) > 1:
            message_to_process = sqs_messages[1]
            message_to_process = json.loads(message_to_process["Body"])
            
            video_file = message_to_process["video"].split('/')[-1]
            video_name = video_file.rsplit('.',1)[0]
            video_download_path = f'/tmp/{video_file}'
            
            bucket = message_to_process["video"].split('/')[0]
            video_s3_key = message_to_process["video"].split('/',1)[1]
            
            s3_client.download_file(bucket, video_s3_key, video_download_path)

            data = message_to_process
            data['video'] = ("video.mp4", open(video_download_path, "rb").read(), "video/mp4")
            
            payload, content_type = urllib3.encode_multipart_formdata(data)
            
            response = sage_client.invoke_endpoint(
                EndpointName=endpoint_name,
                ContentType=content_type,
                Body=payload
            )           
            
            # Read success/failure response
            response_code = response['ResponseMetadata']['HTTPStatusCode']
            response_body = response['Body'].read().decode('utf-8')
            response = {'StatusCode': response_code, 'Body':response_body }   
            
            
            print()
            if response_code == 200:
                
                # UPLOAD ENDPOINT RESULT TO S3 (METRICS AND DETECTIONS)
                
                tracking_resume = "".join(json.loads(response_body)['resume']) 
                
                s3_upload_path = f'{video_name}_output'
                s3_metrics_file_path = f'{s3_upload_path}/{video_name}_output.json'
                s3_tracking_resume_file_path = f'{s3_upload_path}/{video_name}_metrics.txt'
                
                
                
                s3_client.put_object(
                    Bucket = bucket,
                    Key = s3_metrics_file_path,
                    Body = response_body,
                    ContentType = 'application/json'
                )
                
                print('{} uploaded successfully to S3 bucket {}'.format(s3_metrics_file_path, bucket))
                
                s3_client.put_object(
                    Bucket = bucket,
                    Key = s3_tracking_resume_file_path,
                    Body = tracking_resume,
                    ContentType = 'text/plain'
                )
                
                print('{} uploaded successfully to S3 bucket {}'.format(s3_tracking_resume_file_path, bucket))
                
                # INVOKE LAMBDA FUNCTION TO POSTPROCESS RESULT
                
                lambda_payload = {
                  "bucket": bucket,
                  "s3_upload_path": s3_upload_path,
                  "s3_video_path": video_s3_key,
                  "s3_metrics_path": s3_metrics_file_path
                }
                
                lambda_client.invoke(
                    FunctionName=postprocess_output_lambda, 
                    InvocationType='Event',
                    Payload=json.dumps(lambda_payload)
                )
                
                # NOTIFY SUCCESSFUL REQUEST PROCESSING
            
                sns.publish(
                    TopicArn=sns_topic_arn,
                    Message=f'{video_file} processed successfully',
                )
                print('Sns notification sent')
            
            return response_body

        response = {'StatusCode': 200, 'Body': "No new video was processed. SQS Queue is empty"} 
        print(response)
        return response
        
        
        return "Done without new processing"
    except Exception as e:
        print(e)
        raise e
